# KAL KIDS FASHION POS

**Professional Offline-First Android POS & Boutique Management System**

Package: `com.kalkidsfashion.pos`  
Platform: Native Android (Kotlin + Jetpack Compose)  
Minimum SDK: 26 (Android 8.0)

---

## Current Status (Phase 1 & 2 Complete)

### ✅ Completed

- Full project structure (Clean Architecture ready)
- Complete Room database schema with 15 entities
- All DAOs for products, variations, inventory, sales, payments, purchases, customers, employees, expenses, settings, returns
- Hilt Dependency Injection module
- Material 3 Theme with KAL KIDS FASHION branding (Pink + Teal)
- Navigation structure (Bottom navigation + More menu)
- Placeholder screens for all major modules
- AndroidManifest with required permissions (Camera, Bluetooth, Storage)
- Build configuration ready for Debug & Release

### Database Schema Highlights

- **Products** + **ProductVariations** (size + color with independent stock & barcodes)
- Full **InventoryMovement** audit trail
- **Sales** + **SaleItems** (historical prices frozen) + **Payments** (split payment support)
- **Purchases** + **PurchaseItems** + **Suppliers**
- **Customers**, **Employees** (PIN hashed), **Expenses**
- **SaleReturns** + **SaleReturnItems**
- **StoreSettings** (tax, receipt, branding)

---

## How to Open & Build

1. Open **Android Studio** (Hedgehog or newer recommended)
2. **File → Open** → select the `KalKidsFashionPOS` folder
3. Let Gradle sync (first time may take a few minutes)
4. Connect a device / start emulator (API 26+)
5. Click **Run**

### Generate APKs

- **Debug APK**: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
- **Release APK**: Configure signing first, then `Build → Generate Signed Bundle / APK`

---

## Next Phases (In Order)

| Phase | Focus                                      | Status     |
|-------|--------------------------------------------|------------|
| 1–2   | Architecture + Database Schema             | ✅ Done    |
| 3     | Authentication + Executive Dashboard       | Next       |
| 4     | Products, Variations & Inventory           | Pending    |
| 5     | POS Cashier Terminal + Payments            | Pending    |
| 6     | Purchases, Suppliers, Customers, Returns  | Pending    |
| 7     | Expenses + Financial Reports               | Pending    |
| 8     | Receipts, Printing, PDF/CSV Export         | Pending    |
| 9     | Backup / Restore + Security hardening     | Pending    |
| 10    | Tests + Release polish                     | Pending    |

---

## Important Notes

- Core operations are designed to work **100% offline**.
- All financial calculations use historical transaction data (correct COGS).
- Stock changes always create an audit movement record.
- Never stores plain-text PINs.
- Sample data and full business logic will be added in subsequent phases.

---

**Developed according to the Master Development Prompt for KAL KIDS FASHION.**

---

## Phase 3 Progress (Authentication + Dashboard)

### ✅ Completed in Phase 3

- **Secure Login Screen** with username + PIN
- **PIN hashing** using PBKDF2 (never plain text)
- **Session management** via DataStore
- **AuthViewModel** + authentication flow
- **Automatic database seeding**:
  - Default Owner account: `admin` / `1234`
  - Store settings for KAL KIDS FASHION
- **Executive Dashboard** with:
  - Period filters (Today / Week / Month / Year)
  - Total Sales + Transaction count
  - Gross Profit (Sales − COGS)
  - Net Profit (Gross − Expenses)
  - Expenses total
  - Product & Variation counts
  - Low stock / Out of stock counts
  - Outstanding supplier balance
  - Payment method breakdown
  - Top selling products
- Logout support
- Navigation gated behind login

### Default Login Credentials
- **Username:** `admin`
- **PIN:** `1234`

> Change the default PIN after first login in production.
