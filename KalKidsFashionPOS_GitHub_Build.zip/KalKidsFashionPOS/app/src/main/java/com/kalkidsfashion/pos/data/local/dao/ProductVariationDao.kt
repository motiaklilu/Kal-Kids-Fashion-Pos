package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.ProductVariationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductVariationDao {

    @Query("SELECT * FROM product_variations WHERE productId = :productId AND isActive = 1")
    fun getVariationsForProduct(productId: Long): Flow<List<ProductVariationEntity>>

    @Query("SELECT * FROM product_variations WHERE productId = :productId AND isActive = 1")
    suspend fun getVariationsForProductSync(productId: Long): List<ProductVariationEntity>

    @Query("SELECT * FROM product_variations WHERE id = :id")
    suspend fun getVariationById(id: Long): ProductVariationEntity?

    @Query("SELECT * FROM product_variations WHERE barcode = :barcode LIMIT 1")
    suspend fun getVariationByBarcode(barcode: String): ProductVariationEntity?

    @Query("SELECT * FROM product_variations WHERE sku = :sku LIMIT 1")
    suspend fun getVariationBySku(sku: String): ProductVariationEntity?

    @Query("""
        SELECT * FROM product_variations 
        WHERE quantityOnHand <= :threshold AND isActive = 1
        ORDER BY quantityOnHand ASC
    """)
    fun getLowStockVariations(threshold: Int): Flow<List<ProductVariationEntity>>

    @Query("SELECT * FROM product_variations WHERE quantityOnHand <= 0 AND isActive = 1")
    fun getOutOfStockVariations(): Flow<List<ProductVariationEntity>>

    @Query("SELECT SUM(quantityOnHand) FROM product_variations WHERE isActive = 1")
    suspend fun getTotalStockQuantity(): Int?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(variation: ProductVariationEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(variations: List<ProductVariationEntity>): List<Long>

    @Update
    suspend fun update(variation: ProductVariationEntity)

    @Query("""
        UPDATE product_variations 
        SET quantityOnHand = quantityOnHand + :delta, updatedAt = :updatedAt 
        WHERE id = :id
    """)
    suspend fun adjustQuantity(id: Long, delta: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM product_variations WHERE isActive = 1")
    suspend fun getActiveVariationCount(): Int

    @Query("SELECT COUNT(*) FROM product_variations WHERE quantityOnHand <= :threshold AND quantityOnHand > 0 AND isActive = 1")
    suspend fun getLowStockCount(threshold: Int): Int

    @Query("SELECT COUNT(*) FROM product_variations WHERE quantityOnHand <= 0 AND isActive = 1")
    suspend fun getOutOfStockCount(): Int
}
