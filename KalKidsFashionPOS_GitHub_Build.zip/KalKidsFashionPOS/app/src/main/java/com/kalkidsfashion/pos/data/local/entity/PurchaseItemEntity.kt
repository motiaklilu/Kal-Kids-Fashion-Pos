package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "purchase_items",
    foreignKeys = [
        ForeignKey(
            entity = PurchaseEntity::class,
            parentColumns = ["id"],
            childColumns = ["purchaseId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ProductVariationEntity::class,
            parentColumns = ["id"],
            childColumns = ["variationId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["purchaseId"]),
        Index(value = ["variationId"])
    ]
)
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val purchaseId: Long,
    val productId: Long,
    val variationId: Long,

    val productName: String,
    val size: String,
    val color: String,
    val sku: String,

    val quantityOrdered: Int,
    val quantityReceived: Int = 0,

    val unitCost: Double,
    val lineTotal: Double
)
