package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Full audit trail for every stock change.
 * Never allow stock changes without a movement record.
 */
@Entity(
    tableName = "inventory_movements",
    foreignKeys = [
        ForeignKey(
            entity = ProductVariationEntity::class,
            parentColumns = ["id"],
            childColumns = ["variationId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["variationId"]),
        Index(value = ["movementType"]),
        Index(value = ["referenceType", "referenceId"]),
        Index(value = ["createdAt"]),
        Index(value = ["employeeId"])
    ]
)
data class InventoryMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val variationId: Long,

    val movementType: String,           // OPENING, PURCHASE, SALE, RETURN, ADJUSTMENT, DAMAGED, LOST, TRANSFER_IN, TRANSFER_OUT, STOCK_COUNT
    val quantityChange: Int,            // Positive = increase, Negative = decrease
    val quantityBefore: Int,
    val quantityAfter: Int,

    val unitCost: Double? = null,       // Cost at the time of movement (important for COGS)

    val referenceType: String? = null,  // SALE, PURCHASE, ADJUSTMENT, RETURN, etc.
    val referenceId: Long? = null,      // ID of the related transaction

    val reason: String? = null,
    val notes: String? = null,

    val employeeId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
