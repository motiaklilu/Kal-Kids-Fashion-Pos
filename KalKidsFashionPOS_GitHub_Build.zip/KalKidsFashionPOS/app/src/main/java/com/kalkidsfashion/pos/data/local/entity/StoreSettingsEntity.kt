package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Single-row store configuration.
 */
@Entity(tableName = "store_settings")
data class StoreSettingsEntity(
    @PrimaryKey
    val id: Int = 1,                    // Always 1 – single store config

    val storeName: String = "KAL KIDS FASHION",
    val storeAddress: String = "",
    val storePhone: String = "",
    val storeEmail: String = "",
    val storeLogoUri: String? = null,

    val taxEnabled: Boolean = true,
    val taxPercent: Double = 15.0,      // Ethiopia VAT example – configurable
    val taxName: String = "VAT",

    val currencyCode: String = "ETB",
    val currencySymbol: String = "Br",

    val receiptFooter: String = "Thank you for shopping with us!\nReturns accepted within 7 days with receipt.",
    val receiptHeader: String = "",

    val lowStockThreshold: Int = 5,
    val allowNegativeStock: Boolean = false,

    val receiptPrinterType: String = "NONE", // NONE, BLUETOOTH, USB
    val lastReceiptNumber: Long = 0,

    val updatedAt: Long = System.currentTimeMillis()
)
