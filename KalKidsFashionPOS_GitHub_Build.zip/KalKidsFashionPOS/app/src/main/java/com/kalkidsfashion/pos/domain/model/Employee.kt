package com.kalkidsfashion.pos.domain.model

data class Employee(
    val id: Long = 0,
    val fullName: String,
    val username: String,
    val role: String,
    val phone: String? = null,
    val email: String? = null,
    val isActive: Boolean = true,
    val lastLoginAt: Long? = null
) {
    val isOwner: Boolean get() = role == EmployeeRoles.OWNER
    val isManager: Boolean get() = role == EmployeeRoles.MANAGER || isOwner
    val canAccessFinancials: Boolean get() = role in listOf(
        EmployeeRoles.OWNER, EmployeeRoles.MANAGER, EmployeeRoles.ACCOUNTANT
    )
    val canManageInventory: Boolean get() = role in listOf(
        EmployeeRoles.OWNER, EmployeeRoles.MANAGER, EmployeeRoles.INVENTORY_MANAGER
    )
    val canProcessSales: Boolean get() = role in listOf(
        EmployeeRoles.OWNER, EmployeeRoles.MANAGER, EmployeeRoles.CASHIER
    )
}

data class AuthSession(
    val employeeId: Long,
    val fullName: String,
    val username: String,
    val role: String,
    val loginAt: Long = System.currentTimeMillis()
)
