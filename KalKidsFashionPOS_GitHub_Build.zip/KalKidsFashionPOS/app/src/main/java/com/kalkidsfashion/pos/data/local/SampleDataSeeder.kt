package com.kalkidsfashion.pos.data.local

import com.kalkidsfashion.pos.data.repository.ProductRepository
import com.kalkidsfashion.pos.data.repository.ProductRepository.VariationInput
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SampleDataSeeder @Inject constructor(
    private val productRepository: ProductRepository
) {
    suspend fun seedSampleProductsIfEmpty() {
        // Only seed if no products exist
        val existing = productRepository.getAllActiveProducts()
        // We check via a simple approach - try to create and ignore duplicates

        val samples = listOf(
            SampleProduct(
                sku = "DRESS-001",
                name = "Girls Floral Summer Dress",
                brand = "KAL Kids",
                category = "Children's clothes",
                purchaseCost = 350.0,
                sellingPrice = 650.0,
                variations = listOf(
                    VariationInput("DRESS-001-2Y-PNK", null, "1–2 Years", "Pink", 12),
                    VariationInput("DRESS-001-3Y-PNK", null, "2–3 Years", "Pink", 15),
                    VariationInput("DRESS-001-4Y-PNK", null, "3–4 Years", "Pink", 10),
                    VariationInput("DRESS-001-2Y-WHT", null, "1–2 Years", "White", 8),
                    VariationInput("DRESS-001-3Y-WHT", null, "2–3 Years", "White", 11)
                )
            ),
            SampleProduct(
                sku = "SHOE-001",
                name = "Kids Soft Sole Shoes",
                brand = "KAL Kids",
                category = "Children's shoes",
                purchaseCost = 280.0,
                sellingPrice = 520.0,
                variations = listOf(
                    VariationInput("SHOE-001-20-BLU", null, "20", "Blue", 20),
                    VariationInput("SHOE-001-22-BLU", null, "22", "Blue", 18),
                    VariationInput("SHOE-001-24-PNK", null, "24", "Pink", 15),
                    VariationInput("SHOE-001-26-BLK", null, "26", "Black", 12)
                )
            ),
            SampleProduct(
                sku = "BABY-001",
                name = "Baby Romper Set",
                brand = "KAL Baby",
                category = "Baby clothes",
                purchaseCost = 220.0,
                sellingPrice = 420.0,
                variations = listOf(
                    VariationInput("BABY-001-06M-YLW", null, "0–6 Months", "Yellow", 25),
                    VariationInput("BABY-001-12M-YLW", null, "6–12 Months", "Yellow", 20),
                    VariationInput("BABY-001-06M-WHT", null, "0–6 Months", "White", 22),
                    VariationInput("BABY-001-12M-PNK", null, "6–12 Months", "Pink", 18)
                )
            ),
            SampleProduct(
                sku = "HAT-001",
                name = "Kids Sun Hat",
                brand = "KAL Kids",
                category = "Hats",
                purchaseCost = 80.0,
                sellingPrice = 180.0,
                variations = listOf(
                    VariationInput("HAT-001-OS-BLU", null, "One Size", "Blue", 30),
                    VariationInput("HAT-001-OS-PNK", null, "One Size", "Pink", 28),
                    VariationInput("HAT-001-OS-YLW", null, "One Size", "Yellow", 25)
                )
            ),
            SampleProduct(
                sku = "SOCK-001",
                name = "Children Cotton Socks (3-Pack)",
                brand = "KAL Kids",
                category = "Socks",
                purchaseCost = 60.0,
                sellingPrice = 150.0,
                variations = listOf(
                    VariationInput("SOCK-001-S-WHT", null, "S", "White", 40),
                    VariationInput("SOCK-001-M-WHT", null, "M", "White", 35),
                    VariationInput("SOCK-001-L-WHT", null, "L", "White", 30)
                )
            )
        )

        samples.forEach { sample ->
            try {
                productRepository.createProduct(
                    sku = sample.sku,
                    name = sample.name,
                    brand = sample.brand,
                    category = sample.category,
                    description = null,
                    purchaseCost = sample.purchaseCost,
                    sellingPrice = sample.sellingPrice,
                    wholesalePrice = sample.sellingPrice * 0.85,
                    minStockLevel = 5,
                    variations = sample.variations,
                    employeeId = null
                )
            } catch (_: Exception) {
                // Ignore if already exists
            }
        }
    }

    private data class SampleProduct(
        val sku: String,
        val name: String,
        val brand: String,
        val category: String,
        val purchaseCost: Double,
        val sellingPrice: Double,
        val variations: List<VariationInput>
    )
}
