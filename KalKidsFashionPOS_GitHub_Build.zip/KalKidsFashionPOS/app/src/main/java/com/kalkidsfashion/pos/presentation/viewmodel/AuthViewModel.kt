package com.kalkidsfashion.pos.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kalkidsfashion.pos.data.local.SessionManager
import com.kalkidsfashion.pos.data.repository.EmployeeRepository
import com.kalkidsfashion.pos.domain.model.AuthSession
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthUiState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val session: AuthSession? = null,
    val errorMessage: String? = null,
    val username: String = "",
    val pin: String = ""
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val employeeRepository: EmployeeRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            sessionManager.sessionFlow.collect { session ->
                _uiState.update {
                    it.copy(
                        isLoggedIn = session != null,
                        session = session
                    )
                }
            }
        }
    }

    fun onUsernameChange(value: String) {
        _uiState.update { it.copy(username = value, errorMessage = null) }
    }

    fun onPinChange(value: String) {
        // Only allow digits and max 6
        if (value.length <= 6 && value.all { it.isDigit() }) {
            _uiState.update { it.copy(pin = value, errorMessage = null) }
        }
    }

    fun login() {
        val state = _uiState.value
        if (state.username.isBlank() || state.pin.length < 4) {
            _uiState.update { it.copy(errorMessage = "Enter username and a valid PIN") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            val result = employeeRepository.authenticate(state.username, state.pin)
            result.fold(
                onSuccess = { session ->
                    sessionManager.saveSession(session)
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isLoggedIn = true,
                            session = session,
                            pin = "" // clear pin
                        )
                    }
                },
                onFailure = { e ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = e.message ?: "Login failed"
                        )
                    }
                }
            )
        }
    }

    fun logout() {
        viewModelScope.launch {
            sessionManager.clearSession()
            _uiState.update {
                AuthUiState() // reset
            }
        }
    }
}
