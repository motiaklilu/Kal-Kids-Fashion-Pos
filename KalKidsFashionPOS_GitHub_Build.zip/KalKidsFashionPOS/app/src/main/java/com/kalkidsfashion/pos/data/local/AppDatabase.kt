package com.kalkidsfashion.pos.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.kalkidsfashion.pos.data.local.converter.Converters
import com.kalkidsfashion.pos.data.local.dao.*
import com.kalkidsfashion.pos.data.local.entity.*

@Database(
    entities = [
        ProductEntity::class,
        ProductVariationEntity::class,
        InventoryMovementEntity::class,
        SaleEntity::class,
        SaleItemEntity::class,
        PaymentEntity::class,
        SupplierEntity::class,
        PurchaseEntity::class,
        PurchaseItemEntity::class,
        CustomerEntity::class,
        EmployeeEntity::class,
        ExpenseEntity::class,
        StoreSettingsEntity::class,
        SaleReturnEntity::class,
        SaleReturnItemEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
    abstract fun productVariationDao(): ProductVariationDao
    abstract fun inventoryMovementDao(): InventoryMovementDao
    abstract fun saleDao(): SaleDao
    abstract fun saleItemDao(): SaleItemDao
    abstract fun paymentDao(): PaymentDao
    abstract fun supplierDao(): SupplierDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun purchaseItemDao(): PurchaseItemDao
    abstract fun customerDao(): CustomerDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun storeSettingsDao(): StoreSettingsDao
    abstract fun saleReturnDao(): SaleReturnDao
}
