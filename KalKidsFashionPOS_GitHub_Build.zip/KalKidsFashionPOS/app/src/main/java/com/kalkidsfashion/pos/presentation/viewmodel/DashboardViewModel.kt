package com.kalkidsfashion.pos.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kalkidsfashion.pos.data.repository.DashboardRepository
import com.kalkidsfashion.pos.domain.model.DashboardMetrics
import com.kalkidsfashion.pos.domain.model.ReportPeriod
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val isLoading: Boolean = true,
    val metrics: DashboardMetrics = DashboardMetrics(),
    val selectedPeriod: ReportPeriod = ReportPeriod.TODAY,
    val errorMessage: String? = null
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val dashboardRepository: DashboardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadMetrics()
    }

    fun loadMetrics(period: ReportPeriod = _uiState.value.selectedPeriod) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, selectedPeriod = period) }
            try {
                val metrics = dashboardRepository.getMetrics(period)
                _uiState.update {
                    it.copy(isLoading = false, metrics = metrics)
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "Failed to load dashboard"
                    )
                }
            }
        }
    }

    fun refresh() = loadMetrics()
}
