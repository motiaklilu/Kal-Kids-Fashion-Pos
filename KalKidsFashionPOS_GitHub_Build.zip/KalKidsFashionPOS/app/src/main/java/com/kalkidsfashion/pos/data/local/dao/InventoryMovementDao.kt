package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.InventoryMovementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryMovementDao {

    @Insert
    suspend fun insert(movement: InventoryMovementEntity): Long

    @Insert
    suspend fun insertAll(movements: List<InventoryMovementEntity>): List<Long>

    @Query("""
        SELECT * FROM inventory_movements 
        WHERE variationId = :variationId 
        ORDER BY createdAt DESC
    """)
    fun getMovementsForVariation(variationId: Long): Flow<List<InventoryMovementEntity>>

    @Query("""
        SELECT * FROM inventory_movements 
        WHERE createdAt BETWEEN :from AND :to 
        ORDER BY createdAt DESC
    """)
    fun getMovementsByDateRange(from: Long, to: Long): Flow<List<InventoryMovementEntity>>

    @Query("""
        SELECT * FROM inventory_movements 
        WHERE referenceType = :refType AND referenceId = :refId
    """)
    suspend fun getMovementsByReference(refType: String, refId: Long): List<InventoryMovementEntity>
}
