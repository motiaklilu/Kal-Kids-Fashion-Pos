package com.kalkidsfashion.pos.domain.model

data class DashboardMetrics(
    val todaySalesAmount: Double = 0.0,
    val todaySalesCount: Int = 0,
    val todayGrossProfit: Double = 0.0,
    val todayNetProfit: Double = 0.0,
    val todayExpenses: Double = 0.0,

    val totalInventoryValue: Double = 0.0,
    val totalProducts: Int = 0,
    val totalVariations: Int = 0,
    val lowStockCount: Int = 0,
    val outOfStockCount: Int = 0,

    val outstandingSupplierBalance: Double = 0.0,

    val paymentMethodBreakdown: List<PaymentBreakdown> = emptyList(),
    val topSellingProducts: List<TopProduct> = emptyList(),

    val periodLabel: String = "Today"
)

data class PaymentBreakdown(
    val method: String,
    val amount: Double,
    val percentage: Float = 0f
)

data class TopProduct(
    val productId: Long,
    val productName: String,
    val quantitySold: Int
)

enum class ReportPeriod {
    TODAY, WEEK, MONTH, YEAR, CUSTOM
}
