package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sale_returns",
    foreignKeys = [
        ForeignKey(
            entity = SaleEntity::class,
            parentColumns = ["id"],
            childColumns = ["originalSaleId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["returnNumber"], unique = true),
        Index(value = ["originalSaleId"]),
        Index(value = ["returnDate"])
    ]
)
data class SaleReturnEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val returnNumber: String,
    val originalSaleId: Long,
    val originalReceiptNumber: String,

    val returnDate: Long,
    val processedBy: Long,

    val totalRefundAmount: Double,
    val refundMethod: String,           // CASH, TELEBIRR, etc. or STORE_CREDIT
    val reason: String,

    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
