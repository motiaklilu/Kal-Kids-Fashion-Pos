package com.kalkidsfashion.pos.domain.model

/**
 * Domain model for a product (UI / business logic layer).
 * Separated from Room entities for clean architecture.
 */
data class Product(
    val id: Long = 0,
    val sku: String,
    val name: String,
    val brand: String? = null,
    val category: String,
    val description: String? = null,
    val imageUri: String? = null,
    val supplierId: Long? = null,
    val purchaseCost: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val wholesalePrice: Double? = null,
    val minStockLevel: Int = 5,
    val isActive: Boolean = true,
    val variations: List<ProductVariation> = emptyList(),
    val totalStock: Int = 0
)

data class ProductVariation(
    val id: Long = 0,
    val productId: Long,
    val sku: String,
    val barcode: String? = null,
    val size: String,
    val color: String,
    val quantityOnHand: Int = 0,
    val purchaseCost: Double? = null,
    val sellingPrice: Double? = null,
    val isActive: Boolean = true
) {
    val displayName: String
        get() = "$size / $color"
}
