package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Each size + color combination is a separate sellable unit with its own stock & barcode.
 */
@Entity(
    tableName = "product_variations",
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["productId"]),
        Index(value = ["sku"], unique = true),
        Index(value = ["barcode"], unique = true),
        Index(value = ["size"]),
        Index(value = ["color"])
    ]
)
data class ProductVariationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val productId: Long,

    val sku: String,                    // Unique variation SKU (e.g. DRESS-001-2Y-PNK)
    val barcode: String? = null,        // EAN/UPC or internal barcode

    val size: String,                   // 0-6 Months, 1-2 Years, etc.
    val color: String,                  // White, Pink, Blue...

    val quantityOnHand: Int = 0,
    val quantityReserved: Int = 0,      // For held carts (optional)

    // Override prices if different from parent product
    val purchaseCost: Double? = null,
    val sellingPrice: Double? = null,
    val wholesalePrice: Double? = null,

    val isActive: Boolean = true,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
