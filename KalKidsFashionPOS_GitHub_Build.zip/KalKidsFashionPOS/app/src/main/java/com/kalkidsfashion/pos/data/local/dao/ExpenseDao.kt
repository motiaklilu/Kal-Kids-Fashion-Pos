package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.ExpenseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    @Insert
    suspend fun insert(expense: ExpenseEntity): Long

    @Update
    suspend fun update(expense: ExpenseEntity)

    @Query("SELECT * FROM expenses ORDER BY expenseDate DESC")
    fun getAll(): Flow<List<ExpenseEntity>>

    @Query("""
        SELECT * FROM expenses 
        WHERE expenseDate BETWEEN :from AND :to 
        ORDER BY expenseDate DESC
    """)
    fun getByDateRange(from: Long, to: Long): Flow<List<ExpenseEntity>>

    @Query("""
        SELECT COALESCE(SUM(amount), 0) FROM expenses 
        WHERE expenseDate BETWEEN :from AND :to
    """)
    suspend fun getTotalExpenses(from: Long, to: Long): Double

    @Query("""
        SELECT category, SUM(amount) as total 
        FROM expenses 
        WHERE expenseDate BETWEEN :from AND :to
        GROUP BY category
    """)
    suspend fun getExpensesByCategory(from: Long, to: Long): List<CategoryTotal>

    data class CategoryTotal(
        val category: String,
        val total: Double
    )
}
