package com.kalkidsfashion.pos.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.kalkidsfashion.pos.domain.model.AuthSession
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "session")

@Singleton
class SessionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    private object Keys {
        val EMPLOYEE_ID = longPreferencesKey("employee_id")
        val FULL_NAME = stringPreferencesKey("full_name")
        val USERNAME = stringPreferencesKey("username")
        val ROLE = stringPreferencesKey("role")
        val LOGIN_AT = longPreferencesKey("login_at")
    }

    val sessionFlow: Flow<AuthSession?> = dataStore.data.map { prefs ->
        val id = prefs[Keys.EMPLOYEE_ID] ?: return@map null
        val name = prefs[Keys.FULL_NAME] ?: return@map null
        val username = prefs[Keys.USERNAME] ?: return@map null
        val role = prefs[Keys.ROLE] ?: return@map null
        val loginAt = prefs[Keys.LOGIN_AT] ?: System.currentTimeMillis()
        AuthSession(id, name, username, role, loginAt)
    }

    suspend fun saveSession(session: AuthSession) {
        dataStore.edit { prefs ->
            prefs[Keys.EMPLOYEE_ID] = session.employeeId
            prefs[Keys.FULL_NAME] = session.fullName
            prefs[Keys.USERNAME] = session.username
            prefs[Keys.ROLE] = session.role
            prefs[Keys.LOGIN_AT] = session.loginAt
        }
    }

    suspend fun clearSession() {
        dataStore.edit { it.clear() }
    }
}
