package com.kalkidsfashion.pos.domain.model

object ProductCategories {
    val ALL = listOf(
        "Children's clothes",
        "Baby clothes",
        "Children's shoes",
        "Bags",
        "Hats",
        "Socks",
        "Accessories",
        "Toys",
        "Other products"
    )
}

object ProductSizes {
    val CHILDREN = listOf(
        "0–6 Months",
        "6–12 Months",
        "1–2 Years",
        "2–3 Years",
        "3–4 Years",
        "4–5 Years",
        "5–6 Years",
        "6–7 Years",
        "7–8 Years",
        "8–9 Years",
        "9–10 Years",
        "10–12 Years",
        "One Size"
    )
}

object ProductColors {
    val COMMON = listOf(
        "White", "Pink", "Blue", "Black", "Yellow",
        "Red", "Green", "Purple", "Orange", "Grey",
        "Beige", "Brown", "Multicolor"
    )
}

object PaymentMethods {
    const val CASH = "CASH"
    const val TELEBIRR = "TELEBIRR"
    const val CBE_BIRR = "CBE_BIRR"
    const val BANK_TRANSFER = "BANK_TRANSFER"
    const val OTHER = "OTHER"

    val ALL = listOf(CASH, TELEBIRR, CBE_BIRR, BANK_TRANSFER, OTHER)
}

object EmployeeRoles {
    const val OWNER = "OWNER"
    const val MANAGER = "MANAGER"
    const val CASHIER = "CASHIER"
    const val INVENTORY_MANAGER = "INVENTORY_MANAGER"
    const val ACCOUNTANT = "ACCOUNTANT"

    val ALL = listOf(OWNER, MANAGER, CASHIER, INVENTORY_MANAGER, ACCOUNTANT)
}

object ExpenseCategories {
    val ALL = listOf(
        "Rent",
        "Electricity",
        "Water",
        "Internet",
        "Employee salaries",
        "Transportation",
        "Packaging",
        "Marketing",
        "Maintenance",
        "Other expenses"
    )
}

object MovementTypes {
    const val OPENING = "OPENING"
    const val PURCHASE = "PURCHASE"
    const val SALE = "SALE"
    const val RETURN = "RETURN"
    const val ADJUSTMENT = "ADJUSTMENT"
    const val DAMAGED = "DAMAGED"
    const val LOST = "LOST"
    const val TRANSFER_IN = "TRANSFER_IN"
    const val TRANSFER_OUT = "TRANSFER_OUT"
    const val STOCK_COUNT = "STOCK_COUNT"
}

object SaleStatus {
    const val COMPLETED = "COMPLETED"
    const val CANCELLED = "CANCELLED"
    const val PARTIALLY_RETURNED = "PARTIALLY_RETURNED"
    const val FULLY_RETURNED = "FULLY_RETURNED"
}
