package com.kalkidsfashion.pos.di

import android.content.Context
import androidx.room.Room
import com.kalkidsfashion.pos.data.local.AppDatabase
import com.kalkidsfashion.pos.data.local.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "kal_kids_fashion_pos.db"
        )
            .fallbackToDestructiveMigration() // Only for initial development – replace with proper migrations later
            .build()
    }

    @Provides fun provideProductDao(db: AppDatabase): ProductDao = db.productDao()
    @Provides fun provideProductVariationDao(db: AppDatabase): ProductVariationDao = db.productVariationDao()
    @Provides fun provideInventoryMovementDao(db: AppDatabase): InventoryMovementDao = db.inventoryMovementDao()
    @Provides fun provideSaleDao(db: AppDatabase): SaleDao = db.saleDao()
    @Provides fun provideSaleItemDao(db: AppDatabase): SaleItemDao = db.saleItemDao()
    @Provides fun providePaymentDao(db: AppDatabase): PaymentDao = db.paymentDao()
    @Provides fun provideSupplierDao(db: AppDatabase): SupplierDao = db.supplierDao()
    @Provides fun providePurchaseDao(db: AppDatabase): PurchaseDao = db.purchaseDao()
    @Provides fun providePurchaseItemDao(db: AppDatabase): PurchaseItemDao = db.purchaseItemDao()
    @Provides fun provideCustomerDao(db: AppDatabase): CustomerDao = db.customerDao()
    @Provides fun provideEmployeeDao(db: AppDatabase): EmployeeDao = db.employeeDao()
    @Provides fun provideExpenseDao(db: AppDatabase): ExpenseDao = db.expenseDao()
    @Provides fun provideStoreSettingsDao(db: AppDatabase): StoreSettingsDao = db.storeSettingsDao()
    @Provides fun provideSaleReturnDao(db: AppDatabase): SaleReturnDao = db.saleReturnDao()
}
