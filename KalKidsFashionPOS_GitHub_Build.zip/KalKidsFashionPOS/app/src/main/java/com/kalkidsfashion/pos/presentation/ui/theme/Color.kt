package com.kalkidsfashion.pos.presentation.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors for KAL KIDS FASHION – soft, premium boutique feel
val PinkPrimary = Color(0xFFE91E63)
val PinkLight = Color(0xFFF8BBD9)
val PinkDark = Color(0xFFC2185B)

val TealSecondary = Color(0xFF009688)
val TealLight = Color(0xFFB2DFDB)
val TealDark = Color(0xFF00796B)

val NeutralBackground = Color(0xFFFDF8F9)
val NeutralSurface = Color(0xFFFFFFFF)
val NeutralOnSurface = Color(0xFF1C1B1F)

// Status colors
val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFEF6C00)
val ErrorRed = Color(0xFFC62828)
val InfoBlue = Color(0xFF1565C0)

// Dark theme
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkOnSurface = Color(0xFFE6E1E5)
