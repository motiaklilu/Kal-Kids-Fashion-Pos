package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(
            entity = SaleEntity::class,
            parentColumns = ["id"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ProductVariationEntity::class,
            parentColumns = ["id"],
            childColumns = ["variationId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["saleId"]),
        Index(value = ["variationId"]),
        Index(value = ["productId"])
    ]
)
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val saleId: Long,
    val productId: Long,
    val variationId: Long,

    // Snapshot of product data at time of sale (never changes later)
    val productName: String,
    val size: String,
    val color: String,
    val sku: String,
    val barcode: String? = null,

    val quantity: Int,
    val unitPrice: Double,              // Selling price at time of sale
    val unitCost: Double,               // Cost at time of sale (for accurate COGS)
    val discountAmount: Double = 0.0,
    val lineTotal: Double,              // (unitPrice * quantity) - discountAmount

    val returnedQuantity: Int = 0       // Tracks partial returns
)
