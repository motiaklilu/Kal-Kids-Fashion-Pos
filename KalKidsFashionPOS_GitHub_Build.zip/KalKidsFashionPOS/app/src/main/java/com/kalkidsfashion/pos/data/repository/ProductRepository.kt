package com.kalkidsfashion.pos.data.repository

import com.kalkidsfashion.pos.data.local.dao.InventoryMovementDao
import com.kalkidsfashion.pos.data.local.dao.ProductDao
import com.kalkidsfashion.pos.data.local.dao.ProductVariationDao
import com.kalkidsfashion.pos.data.local.entity.InventoryMovementEntity
import com.kalkidsfashion.pos.data.local.entity.ProductEntity
import com.kalkidsfashion.pos.data.local.entity.ProductVariationEntity
import com.kalkidsfashion.pos.domain.model.MovementTypes
import com.kalkidsfashion.pos.domain.model.Product
import com.kalkidsfashion.pos.domain.model.ProductVariation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProductRepository @Inject constructor(
    private val productDao: ProductDao,
    private val variationDao: ProductVariationDao,
    private val movementDao: InventoryMovementDao
) {

    fun getAllActiveProducts(): Flow<List<Product>> {
        return productDao.getAllActiveProducts().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun searchProducts(query: String): Flow<List<Product>> {
        return if (query.isBlank()) getAllActiveProducts()
        else productDao.searchProducts(query).map { list -> list.map { it.toDomain() } }
    }

    fun getProductsByCategory(category: String): Flow<List<Product>> {
        return productDao.getProductsByCategory(category).map { list -> list.map { it.toDomain() } }
    }

    fun getCategories(): Flow<List<String>> = productDao.getAllCategories()

    suspend fun getProductWithVariations(productId: Long): Product? {
        val product = productDao.getProductById(productId) ?: return null
        val variations = variationDao.getVariationsForProductSync(productId)
        return product.toDomain().copy(
            variations = variations.map { it.toDomain() },
            totalStock = variations.sumOf { it.quantityOnHand }
        )
    }

    suspend fun getVariationByBarcode(barcode: String): ProductVariation? {
        return variationDao.getVariationByBarcode(barcode)?.toDomain()
    }

    suspend fun createProduct(
        sku: String,
        name: String,
        brand: String?,
        category: String,
        description: String?,
        purchaseCost: Double,
        sellingPrice: Double,
        wholesalePrice: Double?,
        minStockLevel: Int,
        variations: List<VariationInput>,
        employeeId: Long?
    ): Result<Long> {
        if (productDao.getProductBySku(sku) != null) {
            return Result.failure(Exception("SKU already exists"))
        }

        val productId = productDao.insert(
            ProductEntity(
                sku = sku.trim().uppercase(),
                name = name.trim(),
                brand = brand?.trim(),
                category = category,
                description = description?.trim(),
                purchaseCost = purchaseCost,
                sellingPrice = sellingPrice,
                wholesalePrice = wholesalePrice,
                minStockLevel = minStockLevel,
                createdBy = employeeId
            )
        )

        variations.forEach { v ->
            val variationId = variationDao.insert(
                ProductVariationEntity(
                    productId = productId,
                    sku = v.sku.trim().uppercase(),
                    barcode = v.barcode?.trim(),
                    size = v.size,
                    color = v.color,
                    quantityOnHand = v.initialStock,
                    purchaseCost = v.purchaseCost ?: purchaseCost,
                    sellingPrice = v.sellingPrice ?: sellingPrice
                )
            )
            if (v.initialStock > 0) {
                movementDao.insert(
                    InventoryMovementEntity(
                        variationId = variationId,
                        movementType = MovementTypes.OPENING,
                        quantityChange = v.initialStock,
                        quantityBefore = 0,
                        quantityAfter = v.initialStock,
                        unitCost = v.purchaseCost ?: purchaseCost,
                        reason = "Opening stock",
                        employeeId = employeeId
                    )
                )
            }
        }
        return Result.success(productId)
    }

    suspend fun adjustStock(
        variationId: Long,
        quantityChange: Int,
        movementType: String,
        reason: String,
        employeeId: Long?
    ): Result<Unit> {
        val variation = variationDao.getVariationById(variationId)
            ?: return Result.failure(Exception("Variation not found"))

        val newQty = variation.quantityOnHand + quantityChange
        if (newQty < 0) {
            return Result.failure(Exception("Insufficient stock"))
        }

        variationDao.adjustQuantity(variationId, quantityChange)
        movementDao.insert(
            InventoryMovementEntity(
                variationId = variationId,
                movementType = movementType,
                quantityChange = quantityChange,
                quantityBefore = variation.quantityOnHand,
                quantityAfter = newQty,
                unitCost = variation.purchaseCost,
                reason = reason,
                employeeId = employeeId
            )
        )
        return Result.success(Unit)
    }

    fun getLowStockVariations(threshold: Int): Flow<List<ProductVariationEntity>> {
        return variationDao.getLowStockVariations(threshold)
    }

    data class VariationInput(
        val sku: String,
        val barcode: String? = null,
        val size: String,
        val color: String,
        val initialStock: Int = 0,
        val purchaseCost: Double? = null,
        val sellingPrice: Double? = null
    )

    private fun ProductEntity.toDomain() = Product(
        id = id,
        sku = sku,
        name = name,
        brand = brand,
        category = category,
        description = description,
        imageUri = imageUri,
        supplierId = supplierId,
        purchaseCost = purchaseCost,
        sellingPrice = sellingPrice,
        wholesalePrice = wholesalePrice,
        minStockLevel = minStockLevel,
        isActive = isActive
    )

    private fun ProductVariationEntity.toDomain() = ProductVariation(
        id = id,
        productId = productId,
        sku = sku,
        barcode = barcode,
        size = size,
        color = color,
        quantityOnHand = quantityOnHand,
        purchaseCost = purchaseCost,
        sellingPrice = sellingPrice,
        isActive = isActive
    )
}
