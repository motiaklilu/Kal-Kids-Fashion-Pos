package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Completed sales header.
 * Historical prices are frozen at sale time.
 */
@Entity(
    tableName = "sales",
    indices = [
        Index(value = ["receiptNumber"], unique = true),
        Index(value = ["saleDate"]),
        Index(value = ["cashierId"]),
        Index(value = ["customerId"]),
        Index(value = ["status"]),
        Index(value = ["createdAt"])
    ]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val receiptNumber: String,          // Unique human-readable receipt number

    val saleDate: Long,                 // Epoch millis
    val cashierId: Long,
    val customerId: Long? = null,       // null = Walk-in

    val subtotal: Double,
    val discountAmount: Double = 0.0,
    val discountPercent: Double = 0.0,
    val taxAmount: Double = 0.0,
    val taxPercent: Double = 0.0,
    val grandTotal: Double,

    val amountPaid: Double,
    val changeDue: Double = 0.0,

    val status: String = "COMPLETED",   // COMPLETED, CANCELLED, PARTIALLY_RETURNED, FULLY_RETURNED
    val notes: String? = null,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),

    // Cancellation / reversal tracking
    val cancelledAt: Long? = null,
    val cancelledBy: Long? = null,
    val cancellationReason: String? = null
)
