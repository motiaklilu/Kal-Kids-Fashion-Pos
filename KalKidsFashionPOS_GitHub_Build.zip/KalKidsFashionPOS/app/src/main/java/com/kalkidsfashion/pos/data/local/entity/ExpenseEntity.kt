package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "expenses",
    indices = [
        Index(value = ["expenseNumber"], unique = true),
        Index(value = ["category"]),
        Index(value = ["expenseDate"]),
        Index(value = ["employeeId"])
    ]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val expenseNumber: String,
    val category: String,               // RENT, ELECTRICITY, WATER, INTERNET, SALARY, TRANSPORT, PACKAGING, MARKETING, MAINTENANCE, OTHER
    val description: String,
    val amount: Double,

    val paymentMethod: String,          // CASH, TELEBIRR, CBE_BIRR, BANK_TRANSFER
    val expenseDate: Long,

    val employeeId: Long? = null,       // Who recorded it
    val attachmentUri: String? = null,
    val notes: String? = null,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
