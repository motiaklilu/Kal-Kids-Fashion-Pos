package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "purchases",
    foreignKeys = [
        ForeignKey(
            entity = SupplierEntity::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["purchaseNumber"], unique = true),
        Index(value = ["supplierId"]),
        Index(value = ["purchaseDate"]),
        Index(value = ["status"])
    ]
)
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val purchaseNumber: String,         // Unique PO / Invoice number
    val supplierId: Long,

    val purchaseDate: Long,
    val expectedDeliveryDate: Long? = null,
    val receivedDate: Long? = null,

    val subtotal: Double,
    val discountAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val shippingCost: Double = 0.0,
    val grandTotal: Double,

    val amountPaid: Double = 0.0,
    val balanceDue: Double = 0.0,

    val status: String = "ORDERED",     // ORDERED, PARTIALLY_RECEIVED, RECEIVED, CANCELLED
    val notes: String? = null,

    val createdBy: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
