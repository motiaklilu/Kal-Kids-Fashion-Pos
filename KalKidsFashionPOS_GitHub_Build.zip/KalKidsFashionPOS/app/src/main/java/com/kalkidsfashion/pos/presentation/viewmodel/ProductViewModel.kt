package com.kalkidsfashion.pos.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kalkidsfashion.pos.data.repository.ProductRepository
import com.kalkidsfashion.pos.domain.model.Product
import com.kalkidsfashion.pos.domain.model.ProductCategories
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProductUiState(
    val isLoading: Boolean = true,
    val products: List<Product> = emptyList(),
    val categories: List<String> = ProductCategories.ALL,
    val selectedCategory: String? = null,
    val searchQuery: String = "",
    val errorMessage: String? = null,
    val successMessage: String? = null
)

@HiltViewModel
class ProductViewModel @Inject constructor(
    private val productRepository: ProductRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow<String?>(null)

    private val _uiState = MutableStateFlow(ProductUiState())
    val uiState: StateFlow<ProductUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                _searchQuery,
                _selectedCategory,
                productRepository.getCategories()
            ) { query, category, cats ->
                Triple(query, category, cats)
            }.collectLatest { (query, category, cats) ->
                _uiState.update { it.copy(categories = cats.ifEmpty { ProductCategories.ALL }, isLoading = true) }

                val flow = when {
                    !query.isBlank() -> productRepository.searchProducts(query)
                    category != null -> productRepository.getProductsByCategory(category)
                    else -> productRepository.getAllActiveProducts()
                }

                flow.collect { products ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            products = products,
                            searchQuery = query,
                            selectedCategory = category
                        )
                    }
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun onCategorySelected(category: String?) {
        _selectedCategory.value = category
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }
}
