package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Supports multiple payment methods per sale (split payment).
 */
@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = SaleEntity::class,
            parentColumns = ["id"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["saleId"]),
        Index(value = ["paymentMethod"]),
        Index(value = ["createdAt"])
    ]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val saleId: Long,

    val paymentMethod: String,          // CASH, TELEBIRR, CBE_BIRR, BANK_TRANSFER, OTHER
    val amount: Double,

    // For electronic payments
    val referenceNumber: String? = null,
    val confirmationStatus: String = "RECORDED", // RECORDED, CONFIRMED, FAILED (manual entry)

    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val recordedBy: Long? = null
)
