package com.kalkidsfashion.pos.data.local

import com.kalkidsfashion.pos.data.local.dao.EmployeeDao
import com.kalkidsfashion.pos.data.local.dao.StoreSettingsDao
import com.kalkidsfashion.pos.data.local.entity.EmployeeEntity
import com.kalkidsfashion.pos.data.local.entity.StoreSettingsEntity
import com.kalkidsfashion.pos.domain.model.EmployeeRoles
import com.kalkidsfashion.pos.domain.security.PinHasher
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DatabaseSeeder @Inject constructor(
    private val employeeDao: EmployeeDao,
    private val settingsDao: StoreSettingsDao
) {
    suspend fun seedIfNeeded() {
        // Seed default owner if no employees exist
        val existing = employeeDao.getByUsername("admin")
        if (existing == null) {
            val (hash, salt) = PinHasher.hashPin("1234")
            employeeDao.insert(
                EmployeeEntity(
                    fullName = "Store Owner",
                    username = "admin",
                    pinHash = hash,
                    pinSalt = salt,
                    role = EmployeeRoles.OWNER
                )
            )
        }

        // Seed store settings if missing
        if (settingsDao.getSettingsSync() == null) {
            settingsDao.insertOrUpdate(
                StoreSettingsEntity(
                    storeName = "KAL KIDS FASHION",
                    storeAddress = "Addis Ababa, Ethiopia",
                    storePhone = "+251 9XX XXX XXX",
                    taxEnabled = true,
                    taxPercent = 15.0,
                    taxName = "VAT",
                    currencyCode = "ETB",
                    currencySymbol = "Br",
                    receiptFooter = "Thank you for shopping with KAL KIDS FASHION!\nReturns accepted within 7 days with original receipt.",
                    lowStockThreshold = 5,
                    allowNegativeStock = false
                )
            )
        }
    }
}
