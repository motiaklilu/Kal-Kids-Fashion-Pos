package com.kalkidsfashion.pos.domain.security

import java.security.SecureRandom
import java.security.spec.KeySpec
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Secure PIN hashing using PBKDF2.
 * Never store plain text PINs.
 */
object PinHasher {

    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH = 256
    private const val SALT_LENGTH = 16

    fun hashPin(pin: String): Pair<String, String> {
        val salt = ByteArray(SALT_LENGTH).also { SecureRandom().nextBytes(it) }
        val hash = pbkdf2(pin.toCharArray(), salt)
        return hash.toHex() to salt.toHex()
    }

    fun verifyPin(pin: String, storedHash: String, storedSalt: String): Boolean {
        val salt = storedSalt.hexToBytes()
        val computed = pbkdf2(pin.toCharArray(), salt)
        return computed.toHex() == storedHash
    }

    private fun pbkdf2(password: CharArray, salt: ByteArray): ByteArray {
        val spec: KeySpec = PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.hexToBytes(): ByteArray {
        check(length % 2 == 0) { "Must have even length" }
        return chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }
}
