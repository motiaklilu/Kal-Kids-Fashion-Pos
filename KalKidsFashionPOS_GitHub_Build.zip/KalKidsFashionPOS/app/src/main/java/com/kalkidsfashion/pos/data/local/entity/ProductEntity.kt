package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Core product (parent). Variations (size + color) hold the actual stock and barcodes.
 */
@Entity(
    tableName = "products",
    indices = [
        Index(value = ["sku"], unique = true),
        Index(value = ["category"]),
        Index(value = ["supplierId"]),
        Index(value = ["name"]),
        Index(value = ["isActive"])
    ]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val sku: String,                    // Parent SKU (e.g. DRESS-001)
    val name: String,
    val brand: String? = null,
    val category: String,               // Children's clothes, Baby clothes, etc.
    val description: String? = null,
    val imageUri: String? = null,       // Local file path or content URI

    val supplierId: Long? = null,

    val purchaseCost: Double = 0.0,     // Default / average cost
    val sellingPrice: Double = 0.0,     // Default selling price
    val wholesalePrice: Double? = null,

    val minStockLevel: Int = 5,
    val isActive: Boolean = true,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: Long? = null,
    val updatedBy: Long? = null
)
