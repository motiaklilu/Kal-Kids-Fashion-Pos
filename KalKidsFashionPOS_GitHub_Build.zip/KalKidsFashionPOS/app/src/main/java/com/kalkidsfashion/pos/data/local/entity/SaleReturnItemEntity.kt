package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sale_return_items",
    foreignKeys = [
        ForeignKey(
            entity = SaleReturnEntity::class,
            parentColumns = ["id"],
            childColumns = ["returnId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["returnId"]), Index(value = ["variationId"])]
)
data class SaleReturnItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val returnId: Long,
    val originalSaleItemId: Long,
    val variationId: Long,

    val productName: String,
    val size: String,
    val color: String,
    val quantityReturned: Int,
    val unitPrice: Double,
    val refundAmount: Double,

    val restock: Boolean = true,        // Whether to put back into inventory
    val condition: String = "GOOD"      // GOOD, DAMAGED, DEFECTIVE
)
