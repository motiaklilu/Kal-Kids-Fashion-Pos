package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.PaymentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {

    @Insert
    suspend fun insert(payment: PaymentEntity): Long

    @Insert
    suspend fun insertAll(payments: List<PaymentEntity>): List<Long>

    @Query("SELECT * FROM payments WHERE saleId = :saleId")
    suspend fun getPaymentsForSale(saleId: Long): List<PaymentEntity>

    @Query("""
        SELECT paymentMethod, SUM(amount) as total 
        FROM payments p
        INNER JOIN sales s ON p.saleId = s.id
        WHERE s.status = 'COMPLETED' AND s.saleDate BETWEEN :from AND :to
        GROUP BY paymentMethod
    """)
    suspend fun getPaymentMethodSummary(from: Long, to: Long): List<PaymentMethodSummary>

    data class PaymentMethodSummary(
        val paymentMethod: String,
        val total: Double
    )
}
