package com.kalkidsfashion.pos.data.repository

import com.kalkidsfashion.pos.data.local.dao.*
import com.kalkidsfashion.pos.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DashboardRepository @Inject constructor(
    private val saleDao: SaleDao,
    private val saleItemDao: SaleItemDao,
    private val paymentDao: PaymentDao,
    private val productDao: ProductDao,
    private val variationDao: ProductVariationDao,
    private val expenseDao: ExpenseDao,
    private val purchaseDao: PurchaseDao,
    private val settingsDao: StoreSettingsDao
) {

    suspend fun getMetrics(period: ReportPeriod = ReportPeriod.TODAY): DashboardMetrics =
        withContext(Dispatchers.IO) {
            val (from, to) = getDateRange(period)
            val settings = settingsDao.getSettingsSync()
            val lowStockThreshold = settings?.lowStockThreshold ?: 5

            // Sales
            val salesAmount = saleDao.getTotalSalesAmount(from, to)
            val salesCount = saleDao.getSalesCount(from, to)

            // Gross profit = Net Sales - COGS
            // We calculate from sale items
            val completedSales = saleDao.getCompletedSalesInRange(from, to)
            var totalCogs = 0.0
            var totalDiscounts = 0.0
            completedSales.forEach { sale ->
                totalDiscounts += sale.discountAmount
                val items = saleItemDao.getItemsForSale(sale.id)
                items.forEach { item ->
                    val soldQty = item.quantity - item.returnedQuantity
                    if (soldQty > 0) {
                        totalCogs += item.unitCost * soldQty
                    }
                }
            }

            val grossProfit = salesAmount - totalCogs
            val expenses = expenseDao.getTotalExpenses(from, to)
            val netProfit = grossProfit - expenses

            // Inventory
            val productCount = productDao.getActiveProductCount()
            val variationCount = variationDao.getActiveVariationCount()
            val lowStockCount = variationDao.getLowStockCount(lowStockThreshold)
            val outOfStockCount = variationDao.getOutOfStockCount()

            val outstanding = purchaseDao.getTotalOutstandingBalance()

            // Payment methods
            val payments = paymentDao.getPaymentMethodSummary(from, to)
            val totalPayments = payments.sumOf { it.total }.coerceAtLeast(0.01)
            val breakdown = payments.map {
                PaymentBreakdown(
                    method = it.paymentMethod,
                    amount = it.total,
                    percentage = (it.total / totalPayments * 100).toFloat()
                )
            }

            // Top products
            val top = saleItemDao.getTopSellingProducts(from, to, 5).map {
                TopProduct(it.productId, it.productName, it.totalSold)
            }

            DashboardMetrics(
                todaySalesAmount = salesAmount,
                todaySalesCount = salesCount,
                todayGrossProfit = grossProfit,
                todayNetProfit = netProfit,
                todayExpenses = expenses,
                totalProducts = productCount,
                totalVariations = variationCount,
                lowStockCount = lowStockCount,
                outOfStockCount = outOfStockCount,
                outstandingSupplierBalance = outstanding,
                paymentMethodBreakdown = breakdown,
                topSellingProducts = top,
                periodLabel = when (period) {
                    ReportPeriod.TODAY -> "Today"
                    ReportPeriod.WEEK -> "This Week"
                    ReportPeriod.MONTH -> "This Month"
                    ReportPeriod.YEAR -> "This Year"
                    ReportPeriod.CUSTOM -> "Custom"
                }
            )
        }

    private fun getDateRange(period: ReportPeriod): Pair<Long, Long> {
        val calendar = Calendar.getInstance()
        val now = calendar.timeInMillis

        when (period) {
            ReportPeriod.TODAY -> {
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                return calendar.timeInMillis to now
            }
            ReportPeriod.WEEK -> {
                calendar.set(Calendar.DAY_OF_WEEK, calendar.firstDayOfWeek)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                return calendar.timeInMillis to now
            }
            ReportPeriod.MONTH -> {
                calendar.set(Calendar.DAY_OF_MONTH, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                return calendar.timeInMillis to now
            }
            ReportPeriod.YEAR -> {
                calendar.set(Calendar.DAY_OF_YEAR, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                return calendar.timeInMillis to now
            }
            ReportPeriod.CUSTOM -> return 0L to now
        }
    }
}
