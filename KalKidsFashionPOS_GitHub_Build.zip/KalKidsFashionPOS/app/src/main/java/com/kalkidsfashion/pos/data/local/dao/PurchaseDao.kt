package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.PurchaseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PurchaseDao {
    @Insert
    suspend fun insert(purchase: PurchaseEntity): Long

    @Update
    suspend fun update(purchase: PurchaseEntity)

    @Query("SELECT * FROM purchases WHERE id = :id")
    suspend fun getById(id: Long): PurchaseEntity?

    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC")
    fun getAll(): Flow<List<PurchaseEntity>>

    @Query("SELECT * FROM purchases WHERE supplierId = :supplierId ORDER BY purchaseDate DESC")
    fun getBySupplier(supplierId: Long): Flow<List<PurchaseEntity>>

    @Query("""
        SELECT COALESCE(SUM(balanceDue), 0) FROM purchases 
        WHERE status != 'CANCELLED' AND balanceDue > 0
    """)
    suspend fun getTotalOutstandingBalance(): Double
}
