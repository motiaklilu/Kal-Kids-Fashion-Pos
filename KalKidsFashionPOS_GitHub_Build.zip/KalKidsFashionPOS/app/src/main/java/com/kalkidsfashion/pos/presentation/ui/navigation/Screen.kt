package com.kalkidsfashion.pos.presentation.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Dashboard : Screen("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard)
    data object POS : Screen("pos", "POS", Icons.Filled.PointOfSale, Icons.Outlined.PointOfSale)
    data object Products : Screen("products", "Products", Icons.Filled.Inventory2, Icons.Outlined.Inventory2)
    data object Inventory : Screen("inventory", "Inventory", Icons.Filled.Warehouse, Icons.Outlined.Warehouse)
    data object Sales : Screen("sales", "Sales", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong)
    data object Purchases : Screen("purchases", "Purchases", Icons.Filled.LocalShipping, Icons.Outlined.LocalShipping)
    data object Expenses : Screen("expenses", "Expenses", Icons.Filled.Payments, Icons.Outlined.Payments)
    data object Reports : Screen("reports", "Reports", Icons.Filled.Assessment, Icons.Outlined.Assessment)
    data object Employees : Screen("employees", "Staff", Icons.Filled.People, Icons.Outlined.People)
    data object Settings : Screen("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
    data object More : Screen("more", "More", Icons.Filled.MoreHoriz, Icons.Outlined.MoreHoriz)
}
