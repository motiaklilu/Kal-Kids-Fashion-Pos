package com.kalkidsfashion.pos.data.repository

import com.kalkidsfashion.pos.data.local.dao.EmployeeDao
import com.kalkidsfashion.pos.data.local.entity.EmployeeEntity
import com.kalkidsfashion.pos.domain.model.AuthSession
import com.kalkidsfashion.pos.domain.model.Employee
import com.kalkidsfashion.pos.domain.security.PinHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EmployeeRepository @Inject constructor(
    private val employeeDao: EmployeeDao
) {

    fun getAllActiveEmployees(): Flow<List<Employee>> {
        return employeeDao.getAllActive().map { list ->
            list.map { it.toDomain() }
        }
    }

    suspend fun getEmployeeById(id: Long): Employee? {
        return employeeDao.getById(id)?.toDomain()
    }

    suspend fun authenticate(username: String, pin: String): Result<AuthSession> {
        val entity = employeeDao.getByUsername(username.trim())
            ?: return Result.failure(Exception("Invalid username or PIN"))

        if (!entity.isActive) {
            return Result.failure(Exception("Account is deactivated"))
        }

        val valid = PinHasher.verifyPin(pin, entity.pinHash, entity.pinSalt)
        if (!valid) {
            return Result.failure(Exception("Invalid username or PIN"))
        }

        employeeDao.updateLastLogin(entity.id)

        val session = AuthSession(
            employeeId = entity.id,
            fullName = entity.fullName,
            username = entity.username,
            role = entity.role
        )
        return Result.success(session)
    }

    suspend fun createEmployee(
        fullName: String,
        username: String,
        pin: String,
        role: String,
        phone: String? = null,
        email: String? = null,
        createdBy: Long? = null
    ): Result<Long> {
        if (employeeDao.getByUsername(username.trim()) != null) {
            return Result.failure(Exception("Username already exists"))
        }
        if (pin.length < 4) {
            return Result.failure(Exception("PIN must be at least 4 digits"))
        }

        val (hash, salt) = PinHasher.hashPin(pin)
        val entity = EmployeeEntity(
            fullName = fullName.trim(),
            username = username.trim().lowercase(),
            pinHash = hash,
            pinSalt = salt,
            role = role,
            phone = phone,
            email = email,
            createdBy = createdBy
        )
        val id = employeeDao.insert(entity)
        return Result.success(id)
    }

    suspend fun changePin(employeeId: Long, oldPin: String, newPin: String): Result<Unit> {
        val entity = employeeDao.getById(employeeId)
            ?: return Result.failure(Exception("Employee not found"))

        if (!PinHasher.verifyPin(oldPin, entity.pinHash, entity.pinSalt)) {
            return Result.failure(Exception("Current PIN is incorrect"))
        }
        if (newPin.length < 4) {
            return Result.failure(Exception("New PIN must be at least 4 digits"))
        }

        val (hash, salt) = PinHasher.hashPin(newPin)
        employeeDao.update(
            entity.copy(
                pinHash = hash,
                pinSalt = salt,
                updatedAt = System.currentTimeMillis()
            )
        )
        return Result.success(Unit)
    }

    private fun EmployeeEntity.toDomain() = Employee(
        id = id,
        fullName = fullName,
        username = username,
        role = role,
        phone = phone,
        email = email,
        isActive = isActive,
        lastLoginAt = lastLoginAt
    )
}
