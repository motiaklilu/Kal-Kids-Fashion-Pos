package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.PurchaseItemEntity

@Dao
interface PurchaseItemDao {
    @Insert
    suspend fun insert(item: PurchaseItemEntity): Long

    @Insert
    suspend fun insertAll(items: List<PurchaseItemEntity>): List<Long>

    @Update
    suspend fun update(item: PurchaseItemEntity)

    @Query("SELECT * FROM purchase_items WHERE purchaseId = :purchaseId")
    suspend fun getItemsForPurchase(purchaseId: Long): List<PurchaseItemEntity>
}
