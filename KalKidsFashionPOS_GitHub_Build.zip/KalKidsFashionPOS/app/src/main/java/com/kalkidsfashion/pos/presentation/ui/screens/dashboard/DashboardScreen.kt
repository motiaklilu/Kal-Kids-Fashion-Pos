package com.kalkidsfashion.pos.presentation.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.kalkidsfashion.pos.domain.model.ReportPeriod
import com.kalkidsfashion.pos.presentation.ui.theme.SuccessGreen
import com.kalkidsfashion.pos.presentation.ui.theme.WarningOrange
import com.kalkidsfashion.pos.presentation.ui.theme.ErrorRed
import com.kalkidsfashion.pos.presentation.viewmodel.AuthViewModel
import com.kalkidsfashion.pos.presentation.viewmodel.DashboardViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    navController: NavController,
    dashboardViewModel: DashboardViewModel = hiltViewModel(),
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val uiState by dashboardViewModel.uiState.collectAsState()
    val authState by authViewModel.uiState.collectAsState()
    val metrics = uiState.metrics
    val currencyFormat = remember {
        NumberFormat.getCurrencyInstance(Locale("en", "ET")).apply {
            currency = java.util.Currency.getInstance("ETB")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Dashboard", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = "Welcome, ${authState.session?.fullName ?: "Staff"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { dashboardViewModel.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = { authViewModel.logout() }) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout")
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { Spacer(Modifier.height(4.dp)) }

                item {
                    PeriodSelector(
                        selected = uiState.selectedPeriod,
                        onSelect = { dashboardViewModel.loadMetrics(it) }
                    )
                }

                item {
                    Text(
                        "Sales Overview – ${metrics.periodLabel}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = "Total Sales",
                            value = currencyFormat.format(metrics.todaySalesAmount),
                            subtitle = "${metrics.todaySalesCount} transactions",
                            icon = Icons.Default.PointOfSale,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Gross Profit",
                            value = currencyFormat.format(metrics.todayGrossProfit),
                            subtitle = "After COGS",
                            icon = Icons.Default.TrendingUp,
                            containerColor = Color(0xFFE8F5E9),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = "Net Profit",
                            value = currencyFormat.format(metrics.todayNetProfit),
                            subtitle = "After expenses",
                            icon = Icons.Default.AccountBalance,
                            containerColor = Color(0xFFE3F2FD),
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Expenses",
                            value = currencyFormat.format(metrics.todayExpenses),
                            subtitle = metrics.periodLabel,
                            icon = Icons.Default.Payments,
                            containerColor = Color(0xFFFFF3E0),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Text(
                        "Inventory Snapshot",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SmallStatCard(
                            label = "Products",
                            value = metrics.totalProducts.toString(),
                            icon = Icons.Outlined.Inventory2,
                            modifier = Modifier.weight(1f)
                        )
                        SmallStatCard(
                            label = "Variations",
                            value = metrics.totalVariations.toString(),
                            icon = Icons.Outlined.Category,
                            modifier = Modifier.weight(1f)
                        )
                        SmallStatCard(
                            label = "Low Stock",
                            value = metrics.lowStockCount.toString(),
                            icon = Icons.Outlined.Warning,
                            valueColor = if (metrics.lowStockCount > 0) WarningOrange else SuccessGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (metrics.outstandingSupplierBalance > 0) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.LocalShipping, contentDescription = null, tint = ErrorRed)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("Outstanding Supplier Payments", style = MaterialTheme.typography.labelLarge)
                                    Text(
                                        currencyFormat.format(metrics.outstandingSupplierBalance),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = ErrorRed
                                    )
                                }
                            }
                        }
                    }
                }

                if (metrics.paymentMethodBreakdown.isNotEmpty()) {
                    item {
                        Text("Payment Methods", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                metrics.paymentMethodBreakdown.forEach { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(item.method.replace("_", " "))
                                        Text(
                                            "${currencyFormat.format(item.amount)}  (${"%.0f".format(item.percentage)}%)",
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (metrics.topSellingProducts.isNotEmpty()) {
                    item {
                        Text("Top Selling Products", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                metrics.topSellingProducts.forEachIndexed { index, product ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "${index + 1}.",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.width(28.dp)
                                        )
                                        Text(product.productName, modifier = Modifier.weight(1f))
                                        Text("${product.quantitySold} sold", fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun PeriodSelector(
    selected: ReportPeriod,
    onSelect: (ReportPeriod) -> Unit
) {
    val periods = listOf(
        ReportPeriod.TODAY to "Today",
        ReportPeriod.WEEK to "Week",
        ReportPeriod.MONTH to "Month",
        ReportPeriod.YEAR to "Year"
    )
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(periods) { (period, label) ->
            FilterChip(
                selected = selected == period,
                onClick = { onSelect(period) },
                label = { Text(label) }
            )
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(text = title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SmallStatCard(
    label: String,
    value: String,
    icon: ImageVector,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier, shape = RoundedCornerShape(12.dp)) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = valueColor)
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
