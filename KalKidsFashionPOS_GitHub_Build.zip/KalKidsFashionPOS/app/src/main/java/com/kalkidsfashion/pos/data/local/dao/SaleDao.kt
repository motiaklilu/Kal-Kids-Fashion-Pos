package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.SaleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SaleDao {

    @Insert
    suspend fun insert(sale: SaleEntity): Long

    @Update
    suspend fun update(sale: SaleEntity)

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun getSaleById(id: Long): SaleEntity?

    @Query("SELECT * FROM sales WHERE receiptNumber = :receiptNumber LIMIT 1")
    suspend fun getSaleByReceiptNumber(receiptNumber: String): SaleEntity?

    @Query("""
        SELECT * FROM sales 
        WHERE saleDate BETWEEN :from AND :to 
        ORDER BY saleDate DESC
    """)
    fun getSalesByDateRange(from: Long, to: Long): Flow<List<SaleEntity>>

    @Query("""
        SELECT * FROM sales 
        WHERE status = 'COMPLETED' AND saleDate BETWEEN :from AND :to
    """)
    suspend fun getCompletedSalesInRange(from: Long, to: Long): List<SaleEntity>

    @Query("""
        SELECT COALESCE(SUM(grandTotal), 0) FROM sales 
        WHERE status = 'COMPLETED' AND saleDate BETWEEN :from AND :to
    """)
    suspend fun getTotalSalesAmount(from: Long, to: Long): Double

    @Query("""
        SELECT COUNT(*) FROM sales 
        WHERE status = 'COMPLETED' AND saleDate BETWEEN :from AND :to
    """)
    suspend fun getSalesCount(from: Long, to: Long): Int

    @Query("SELECT * FROM sales ORDER BY saleDate DESC LIMIT :limit")
    fun getRecentSales(limit: Int = 50): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE cashierId = :cashierId ORDER BY saleDate DESC")
    fun getSalesByCashier(cashierId: Long): Flow<List<SaleEntity>>

    @Query("SELECT * FROM sales WHERE customerId = :customerId ORDER BY saleDate DESC")
    fun getSalesByCustomer(customerId: Long): Flow<List<SaleEntity>>

    @Query("""
        UPDATE sales SET status = :status, updatedAt = :updatedAt,
        cancelledAt = :cancelledAt, cancelledBy = :cancelledBy, cancellationReason = :reason
        WHERE id = :id
    """)
    suspend fun cancelSale(
        id: Long,
        status: String = "CANCELLED",
        updatedAt: Long = System.currentTimeMillis(),
        cancelledAt: Long = System.currentTimeMillis(),
        cancelledBy: Long?,
        reason: String?
    )
}
