package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.SaleItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SaleItemDao {

    @Insert
    suspend fun insert(item: SaleItemEntity): Long

    @Insert
    suspend fun insertAll(items: List<SaleItemEntity>): List<Long>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    suspend fun getItemsForSale(saleId: Long): List<SaleItemEntity>

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
    fun getItemsForSaleFlow(saleId: Long): Flow<List<SaleItemEntity>>

    @Query("""
        SELECT * FROM sale_items 
        WHERE variationId = :variationId 
        ORDER BY id DESC
    """)
    fun getItemsByVariation(variationId: Long): Flow<List<SaleItemEntity>>

    @Query("""
        UPDATE sale_items 
        SET returnedQuantity = returnedQuantity + :qty 
        WHERE id = :id
    """)
    suspend fun increaseReturnedQuantity(id: Long, qty: Int)

    // Top selling products (by quantity)
    @Query("""
        SELECT productId, productName, SUM(quantity - returnedQuantity) as totalSold
        FROM sale_items si
        INNER JOIN sales s ON si.saleId = s.id
        WHERE s.status = 'COMPLETED' AND s.saleDate BETWEEN :from AND :to
        GROUP BY productId, productName
        ORDER BY totalSold DESC
        LIMIT :limit
    """)
    suspend fun getTopSellingProducts(from: Long, to: Long, limit: Int = 10): List<TopSellingProduct>

    data class TopSellingProduct(
        val productId: Long,
        val productName: String,
        val totalSold: Int
    )
}
