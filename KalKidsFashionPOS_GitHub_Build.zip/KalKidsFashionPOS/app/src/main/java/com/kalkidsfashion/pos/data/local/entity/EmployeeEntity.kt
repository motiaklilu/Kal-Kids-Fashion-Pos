package com.kalkidsfashion.pos.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "employees",
    indices = [
        Index(value = ["username"], unique = true),
        Index(value = ["role"]),
        Index(value = ["isActive"])
    ]
)
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val fullName: String,
    val username: String,
    val pinHash: String,                // Never store plain PIN
    val pinSalt: String,

    val role: String,                   // OWNER, MANAGER, CASHIER, INVENTORY_MANAGER, ACCOUNTANT
    val phone: String? = null,
    val email: String? = null,

    val isActive: Boolean = true,
    val lastLoginAt: Long? = null,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: Long? = null
)
