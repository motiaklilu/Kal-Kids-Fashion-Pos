package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.SaleReturnEntity
import com.kalkidsfashion.pos.data.local.entity.SaleReturnItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SaleReturnDao {
    @Insert
    suspend fun insertReturn(saleReturn: SaleReturnEntity): Long

    @Insert
    suspend fun insertReturnItems(items: List<SaleReturnItemEntity>): List<Long>

    @Query("SELECT * FROM sale_returns WHERE id = :id")
    suspend fun getReturnById(id: Long): SaleReturnEntity?

    @Query("SELECT * FROM sale_returns WHERE originalSaleId = :saleId")
    suspend fun getReturnsForSale(saleId: Long): List<SaleReturnEntity>

    @Query("SELECT * FROM sale_return_items WHERE returnId = :returnId")
    suspend fun getItemsForReturn(returnId: Long): List<SaleReturnItemEntity>

    @Query("SELECT * FROM sale_returns ORDER BY returnDate DESC")
    fun getAllReturns(): Flow<List<SaleReturnEntity>>
}
