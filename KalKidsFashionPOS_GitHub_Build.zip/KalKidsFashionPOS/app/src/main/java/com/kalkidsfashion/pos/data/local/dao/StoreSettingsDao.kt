package com.kalkidsfashion.pos.data.local.dao

import androidx.room.*
import com.kalkidsfashion.pos.data.local.entity.StoreSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StoreSettingsDao {
    @Query("SELECT * FROM store_settings WHERE id = 1")
    fun getSettings(): Flow<StoreSettingsEntity?>

    @Query("SELECT * FROM store_settings WHERE id = 1")
    suspend fun getSettingsSync(): StoreSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: StoreSettingsEntity)

    @Query("UPDATE store_settings SET lastReceiptNumber = lastReceiptNumber + 1 WHERE id = 1")
    suspend fun incrementReceiptNumber()

    @Query("SELECT lastReceiptNumber FROM store_settings WHERE id = 1")
    suspend fun getLastReceiptNumber(): Long?
}
