package com.kalkidsfashion.pos.presentation.ui.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kalkidsfashion.pos.presentation.ui.screens.auth.LoginScreen
import com.kalkidsfashion.pos.presentation.ui.screens.dashboard.DashboardScreen
import com.kalkidsfashion.pos.presentation.ui.screens.pos.PosScreen
import com.kalkidsfashion.pos.presentation.ui.screens.products.ProductsScreen
import com.kalkidsfashion.pos.presentation.ui.screens.inventory.InventoryScreen
import com.kalkidsfashion.pos.presentation.ui.screens.sales.SalesScreen
import com.kalkidsfashion.pos.presentation.ui.screens.purchases.PurchasesScreen
import com.kalkidsfashion.pos.presentation.ui.screens.expenses.ExpensesScreen
import com.kalkidsfashion.pos.presentation.ui.screens.reports.ReportsScreen
import com.kalkidsfashion.pos.presentation.ui.screens.employees.EmployeesScreen
import com.kalkidsfashion.pos.presentation.ui.screens.settings.SettingsScreen
import com.kalkidsfashion.pos.presentation.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KalKidsNavGraph(
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val authState by authViewModel.uiState.collectAsState()

    if (!authState.isLoggedIn) {
        LoginScreen(viewModel = authViewModel)
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val mainRoutes = listOf(
        Screen.Dashboard.route,
        Screen.POS.route,
        Screen.Products.route,
        Screen.Sales.route,
        Screen.More.route
    )

    val showBottomBar = currentDestination?.route in mainRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    listOf(
                        Screen.Dashboard,
                        Screen.POS,
                        Screen.Products,
                        Screen.Sales,
                        Screen.More
                    ).forEach { screen ->
                        val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = { Text(screen.title) },
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) { DashboardScreen(navController) }
            composable(Screen.POS.route) { PosScreen(navController) }
            composable(Screen.Products.route) { ProductsScreen(navController) }
            composable(Screen.Inventory.route) { InventoryScreen(navController) }
            composable(Screen.Sales.route) { SalesScreen(navController) }
            composable(Screen.Purchases.route) { PurchasesScreen(navController) }
            composable(Screen.Expenses.route) { ExpensesScreen(navController) }
            composable(Screen.Reports.route) { ReportsScreen(navController) }
            composable(Screen.Employees.route) { EmployeesScreen(navController) }
            composable(Screen.Settings.route) { SettingsScreen(navController) }
            composable(Screen.More.route) { MoreMenuScreen(navController) }
        }
    }
}

@Composable
fun MoreMenuScreen(navController: androidx.navigation.NavController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("More Modules", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        listOf(
            Screen.Inventory,
            Screen.Purchases,
            Screen.Expenses,
            Screen.Reports,
            Screen.Employees,
            Screen.Settings
        ).forEach { screen ->
            TextButton(onClick = { navController.navigate(screen.route) }) {
                Icon(screen.selectedIcon, contentDescription = null)
                Spacer(Modifier.width(12.dp))
                Text(screen.title)
            }
        }
    }
}
